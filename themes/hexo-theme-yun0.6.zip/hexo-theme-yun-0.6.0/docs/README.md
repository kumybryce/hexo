---
home: true
heroImage: /logo.gif
heroText: Hexo-Theme-Yun
tagline: A light & fast & lovely theme for Hexo.
actionText: 快速上手 →
actionLink: /guide/
features:
  - title: 简洁
    details: 简洁、优雅、轻量、自适应的用户界面。
  - title: 快速
    details: 尽可能地优化无用代码，采用 CDN，提高访问速度。
  - title: 可爱
    details: 自以为是的可爱，拥有奇奇怪怪的功能。但不用担心会增加你的最终体积。
# footer: MIT Licensed | Copyright © 2019-2020 YunYouJun
---

<hr/>
<footer style="text-align:center;padding:2rem;color:#4e6e8e">
<a href="https://github.com/YunYouJun/hexo-theme-yun" target="_blank">MIT Licensed</a> | Copyright © 2019-2020 <a href="https://www.yunyoujun.cn" target="_blank">YunYouJun</a>
</footer>
