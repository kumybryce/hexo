# 赞助名单 Sponsor

[骑兵链接｜ Patron Link](https://www.yunyoujun.cn/about/#Donate)

| 老板                                       | 金额(CNY) | 日期       | 寄语           |
| ------------------------------------------ | --------- | ---------- | -------------- |
| [HellSakura](https://HellSakura.github.io) | 2.50      | 2020-04-08 | 冰阔落         |
| [呵呵君](https://hehejun.cn/)              | 1.10      | 2020-04-08 | （逃           |
| [桥带](https://qiaodai-mmm.github.io)      | 2.00      | 2020-04-09 | 冰阔落         |
| [Faery.Xu](https://faeryxu.github.io/)     | 50.00     | 2020-04-09 | 一大桶冰阔落   |
| [神崎日照](https://blog.sernikki.cn/)      | 6.00      | 2020-04-11 | 博士，恰源石啦 |
