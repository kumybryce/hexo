# Icon

The currently used icon

<template></template>
