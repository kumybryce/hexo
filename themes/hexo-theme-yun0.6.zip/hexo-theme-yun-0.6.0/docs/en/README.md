---
home: true
heroImage: /logo.gif
heroText: hexo-theme-yun
tagline: A powerful & simple & fast theme for Hexo.
actionText: Quick Start →
actionLink: /en/guide/
features:
  - title: Simple
    details: Simple, elegant and responsive UI.
  - title: Fast
    details: Optimize useless code as much as possible, and use CDN to increase access speed.
  - title: Lovely
    details: Self-righteous and cute, with strange features. But don't worry about increasing the final size of your blog.
# footer: MIT Licensed | Copyright © 2019-2020 YunYouJun
---

<hr/>
<footer style="text-align:center;padding:2rem;color:#4e6e8e">
<a href="https://github.com/YunYouJun/hexo-theme-yun" target="_blank">MIT Licensed</a> | Copyright © 2019-2020 <a href="https://www.yunyoujun.cn" target="_blank">YunYouJun</a>
</footer>
